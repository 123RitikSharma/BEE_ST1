const express = require('express')
const router = express.Router()

const productController = require('../controllers/productController')

router.get('/', productController.index)
router.post('/show', productController.show)
router.post('/store', productController.store)
router.post('/update', productController.update)
router.post('/delete', productController.destroy)

module.exports = router