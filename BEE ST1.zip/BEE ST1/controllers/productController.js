const { response } = require('express')
const Product = require('../models/ProductSchema')

//Show list of employees
const index = async (req, res , next) => {
    try {
        const result = await Product.find({})

        if (!result) {
            return res.status(400).json({
                message: "Couldn't fetch data"
            })
        }

        return res.status(200).json({
            result
        })
    } catch (error) {
        console.error("Error while fetching product data:", error)
        return res.status(500).json({
            message: "Internal Server Error"
        })
    }
}

const show = (req, res, next) => {
    let productID = req.body.productID
    Product.findById(productID)
        .then(response => {
            res.json({
                response
            })
        })

        .catch(error => {
            res.json({
                message: "An error occured!"
            })
        })
}

const store = (req, res, next) => {
    let product = new Product({
        name: req.body.name,
        description: req.body.description,
        price: req.body.price,
        category: req.body.category
    })

    product.save()
        //A promise to check if the employee is saved successfully
        .then(response => {
            res.json({
                message: "Employee added successfully!"
            })
        })

        .catch(error => {
            res.json({
                message: "An error occured!"
            })
        })
}

//Updating a product using EID
const update = (req, res, next) => {
    let productID = req.body.productID    //ID of the product to be updated

    let updatedData = {   //Changed data
        name: req.body.name,
        description: req.body.description,
        price: req.body.price,
        category: req.body.category
    }

    Product.findByIdAndUpdate(productID, { $set: updatedData })
        .then(() => {
            res.json({
                message: "Employee update successful!"
            })
        })

        .catch(error => {
            res.json({
                message: "An error occured!"
            })
        })
}

//Deleting an employee
const destroy = (req, res, next) => {
    let productID = req.body.productID

    Product.findOneAndDelete(productID)
        .then(() => {
            res.json({
                message: 'Employee delete successful!'
            })
        })

        .catch(error => {
            res.json({
                message: "An error occured!"
            })
        })
}

//Exporting functions
module.exports = {
    index, show, store, update, destroy
}